<div class="alert alert-{{ $type }} alert-dismissible">
    {{ $slot }}
</div>