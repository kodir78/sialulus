<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">

  <title><?php echo $__env->yieldContent('title', 'SIA Sekolah'); ?></title>

  <?php echo $__env->yieldPushContent('before-style'); ?>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="/assets/backend/adminlte30/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="/assets/backend/adminlte30/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="/assets/backend/adminlte30/dist/css/adminlte.min.css">
  <?php echo $__env->yieldPushContent('after-style'); ?>
  <!-- Google Font: Source Sans Pro -->
   <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet"> 
</head>
<body class="hold-transition layout-top-nav">
<div class="wrapper">

  <!-- Navbar -->
      <?php echo $__env->make('includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- /.navbar -->
        <!-- Content Wrapper. Contains page content -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- /.content-wrapper -->

        <!-- Control Sidebar -->
      
        <!-- /.control-sidebar -->
      
        <!-- Main Footer -->
        <footer class="main-footer">
          <!-- To the right -->
          <div class="float-right d-none d-sm-inline">
           Developed by : <a href="zaelani.id">Kodir Zaelani</a>
          </div>
          <!-- Default to the left -->
          <strong>Template by <a href="https://adminlte.io">AdminLTE.io</a>.</strong>  Copyright &copy; 2014-2020 All rights reserved.
        </footer>
      </div>
      <!-- ./wrapper -->
      
      <!-- REQUIRED SCRIPTS -->
      
      <!-- jQuery -->
      <script src="/assets/backend/adminlte30/plugins/jquery/jquery.min.js"></script>
      <!-- Bootstrap 4 -->
      <script src="/assets/backend/adminlte30/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
      <!-- AdminLTE App -->
      <script src="/assets/backend/adminlte30/dist/js/adminlte.min.js"></script>
      <script src="<?php echo e(asset('vendor/datatables/buttons.server-side.js')); ?>"></script>
      <?php echo $__env->yieldPushContent('after-script'); ?>
      </body>
      </html>
      <?php /**PATH D:\serverc\xampp\htdocs\sialulus\resources\views/layouts/default.blade.php ENDPATH**/ ?>