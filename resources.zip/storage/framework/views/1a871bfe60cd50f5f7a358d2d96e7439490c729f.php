
<form id="deleteForm"  class="d-inline" action="<?php echo e(route('graduates.destroy', $model->id)); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <?php echo method_field('delete'); ?>
  <a href="<?php echo e(route('graduates.show', $model->id)); ?>" class="btn btn-xs btn-default edit-row" title="Show"><i class="fas fa-edit"></i></a>  
  
</form>


    <script>
        $('button#del').on('click', function(e){
            e.preventDefault();
            var href = $(this).attr('href');
            Swal.fire({
              title: 'Are you sure?',
              text: "You won't be able to revert this!",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
              if (result.value) {
                document.getElementById('deleteForm').action = href;
                document.getElementById('deleteForm').submit();
                Swal.fire(
                  'Deleted!',
                  'Your file has been deleted.',
                  'success'
                )
              }
            })
        })
    </script><?php /**PATH D:\serverc\xampp\htdocs\sialulus\resources\views/pages/graduates/action.blade.php ENDPATH**/ ?>