<!-- Font Awesome -->
  <link rel="stylesheet" href="/assets/backend/adminlte30/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <!-- Theme style -->
  <link rel="stylesheet" href="/assets/backend/adminlte30/dist/css/adminlte.min.css">
 
   <?php /**PATH D:\serverc\xampp\htdocs\sialulus\resources\views/includes/style.blade.php ENDPATH**/ ?>