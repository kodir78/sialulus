<?php $__env->startSection('title'); ?>
    Tambah User
<?php $__env->stopSection(); ?>
<?php $__env->startPush('after-style'); ?>
<!-- Select2 -->
<link rel="stylesheet" href="/assets/backend/adminlte30/plugins/select2/css/select2.min.css">
<link rel="stylesheet" href="/assets/backend/adminlte30/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
<!-- Jasny Bootstrap 4 -->
<link rel="stylesheet" href="/assets/backend/adminlte30/plugins/jasny-bootstrap/4.0.0/css/jasny-bootstrap.min.css">   
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Add New Users</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('users.index')); ?>">User</a></li>
                        <li class="breadcrumb-item active">Add New</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <?php $__env->startComponent('components.card'); ?>
                        <?php $__env->slot('title'); ?>
                        
                        <?php $__env->endSlot(); ?>
                        
                        <?php if(session('error')): ?>
                            <?php $__env->startComponent('components.alert', ['type' => 'danger']); ?>
                                <?php echo session('error'); ?>

                            <?php echo $__env->renderComponent(); ?>
                        <?php endif; ?>
                        
                        <form action="<?php echo e(route('users.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="">Nama</label>
                                <input type="text" name="name" class="form-control <?php echo e($errors->has('name') ? 'is-invalid':''); ?>" required>
                                <p class="text-danger"><?php echo e($errors->first('name')); ?></p>
                            </div>
                            <div class="form-group">
                                <label for="">Email</label>
                                <input type="email" name="email" class="form-control <?php echo e($errors->has('email') ? 'is-invalid':''); ?>" required>
                                <p class="text-danger"><?php echo e($errors->first('email')); ?></p>
                            </div>
                            <div class="form-group">
                                <label for="">Password</label>
                                <input type="password" name="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid':''); ?>" required>
                                <p class="text-danger"><?php echo e($errors->first('password')); ?></p>
                            </div>
                            <div class="form-group">
                                <label for="">Role</label>
                                <select name="role" class="form-control <?php echo e($errors->has('role') ? 'is-invalid':''); ?>" required>
                                    <option value="">Pilih</option>
                                    <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->name); ?>"><?php echo e($row->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <p class="text-danger"><?php echo e($errors->first('role')); ?></p>
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary btn-sm">
                                    <i class="fa fa-send"></i> Simpan
                                </button>
                            </div>
                        </form>
                        <?php $__env->slot('footer'); ?>

                        <?php $__env->endSlot(); ?>
                    <?php echo $__env->renderComponent(); ?>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('after-script'); ?>
<!-- Select2 -->
<script src="/assets/backend/adminlte30/plugins/select2/js/select2.full.min.js"></script>
<!-- Jasny Bootstrap 4 -->
<script src="/assets/backend/adminlte30/plugins/jasny-bootstrap/4.0.0/js/jasny-bootstrap.min.js"></script>
<script>
        $(function () {
            //Initialize Select2 Elements
            $('.select2').select2()
            
            
            //Initialize Select2 Elements
            $('.select2bs4').select2({
                theme: 'bootstrap4'
            })
            
            $('.summernote').summernote({
                height: "100px",
            });
        });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\serverc\xampp\htdocs\shayna-backend\resources\views/pages/users/create.blade.php ENDPATH**/ ?>