<div class="alert alert-<?php echo e($type); ?> alert-dismissible">
    <?php echo e($slot); ?>

</div><?php /**PATH D:\serverc\xampp\htdocs\shayna-backend\resources\views/components/alert.blade.php ENDPATH**/ ?>