<?php $currentUser = Auth::user() ?>
<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="/" class="brand-link">
      Shayna
      
      <span class="brand-text font-weight-light">Store</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="/assets/backend/adminlte30/dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="/" class="d-block"><?php echo e($currentUser->name); ?></a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="/" class="nav-link">
              <i class="nav-icon fa fa-laptop"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-copy"></i>
              <p>
                Manajemen Produk
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('products.index')); ?>" class="nav-link">
                  <i class="fa fa-list nav-icon"></i>
                  <p>Lihat Produk</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('products.create')); ?>" class="nav-link">
                  <i class="fa fa-plus nav-icon"></i>
                  <p>Tambah Produk</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-edit"></i>
              <p>
                Foto Produk
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('product-galleries.index')); ?>" class="nav-link">
                  <i class="fa fa-list nav-icon"></i>
                  <p>Lihat Foto Produk</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('product-galleries.create')); ?>" class="nav-link">
                  <i class="fa fa-plus nav-icon"></i>
                  <p>Tambah Foto Produk</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-edit"></i>
              <p>
                Transaksi
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('transactions.index')); ?>" class="nav-link">
                  <i class="fa fa-list nav-icon"></i>
                  <p>Lihat Transaksi</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-copy"></i>
              <p>
                Manajemen Role
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('role.index')); ?>" class="nav-link">
                  <i class="fa fa-list nav-icon"></i>
                  <p>Lihat Role</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-copy"></i>
              <p>
                Manajemen User
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('users.index')); ?>" class="nav-link">
                  <i class="fa fa-list nav-icon"></i>
                  <p>Lihat User</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('users.create')); ?>" class="nav-link">
                  <i class="fa fa-plus nav-icon"></i>
                  <p>Tambah User</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('users.roles_permission')); ?>" class="nav-link">
                  <i class="fa fa-plus nav-icon"></i>
                    <p>Role Permission</p>
                </a>
            </li>            
            </ul>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside><?php /**PATH D:\serverc\xampp\htdocs\shayna-backend\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>