<!-- jQuery -->

<!-- Jika modal ditdak tampil maka ganti jQuery dengan jQuery 3.5.1-->

<!-- jQuery -->
<script src="/assets/backend/adminlte30/plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="/assets/backend/adminlte30/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="/assets/backend/adminlte30/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="/assets/backend/adminlte30/plugins/chart.js/Chart.min.js"></script>
<!-- daterangepicker -->
<script src="/assets/backend/adminlte30/plugins/moment/moment.min.js"></script>
<script src="/assets/backend/adminlte30/plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="/assets/backend/adminlte30/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="/assets/backend/adminlte30/plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="/assets/backend/adminlte30/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="/assets/backend/adminlte30/dist/js/adminlte.js"></script>

<?php /**PATH D:\serverc\xampp\htdocs\shayna-backend\resources\views/includes/script.blade.php ENDPATH**/ ?>