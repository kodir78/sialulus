<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>
                        Daftar 
                        <small>Barang</small>
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('products.index')); ?>">Post</a></li>
                        <li class="breadcrumb-item active">Daftar Barang</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <?php if (app('laratrust')->hasRole('admin|operator')) : ?>
                            <a id="add-button" title="Add New" class="btn btn-success" href="<?php echo e(route('products.create')); ?>"><i class="fa fa-plus-circle"></i> Add New</a>
                            <?php endif; // app('laratrust')->hasRole ?>
                            <a href="#mymodal"
                            data-remote="#"
                            data-toggle="modal"
                            data-target="#mymodal"
                            data-title="Import Product"
                            class="btn btn-info">
                            Import
                        </a>
                        <div class="card-tools" style="padding:8px 0px">
                            <form action="<?php echo e(route('products.index')); ?>">
                                <div class="input-group input-group-sm" style="width: 250px;">
                                    <input type="text" name="keyword" class="form-control float-right" placeholder="Search">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        
                        <?php if($errors->has('file')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('file')); ?></strong>
                        </span>
                        <?php endif; ?>
                        
                        
                        

                        <?php if(session('success')): ?>
                            <div class="alert alert-success alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button> 
                            <?php echo e(session('success')); ?>

                            </div>
                            <?php endif; ?>

                            <?php if(session('error')): ?>
                                <div class="alert alert-danger">
                            <button type="button" class="close" data-dismiss="alert">×</button> 
                            <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>
                        <table class="table table-bordered">
                            <thead class="text-center">                  
                                <tr>
                                    
                                    <th>Nama Barang</th>
                                    <th>Tipe</th>
                                    <th>Harga Satuan</th>
                                    <th>Quantity</th>
                                    <th style="width: 130px">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->type); ?> </td>
                                    <td class="text-right"><?php echo e($item->price); ?></td>
                                    <td class="text-right"><?php echo e($item->quantity); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('products.gallery', $item->id)); ?>" class="btn btn-info btn-sm">
                                            <i class="far fa-image"></i>
                                        </a>
                                        <?php if (app('laratrust')->hasRole('editor|admin|')) : ?>
                                        <a href="<?php echo e(route('products.edit', $item->id)); ?>" class="btn btn-primary btn-sm">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <?php endif; // app('laratrust')->hasRole ?>
                                        <form action="<?php echo e(route('products.destroy', $item->id)); ?>" 
                                            method="post" 
                                            class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-danger btn-sm">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center" style="padding: 10px">Data tidak tersedia</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer clearfix">
                        <div class="float-left">
                            <ul class="pagination pagination-sm m-0 float-right">
                                <li class="page-item"><a class="page-link" href="#">&laquo;</a></li>
                                <li class="page-item"><a class="page-link" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item"><a class="page-link" href="#">&raquo;</a></li>
                            </ul>
                        </div>
                        <div class="float-right">
                            <small>Jumlah item barang</small>
                        </div>
                    </div>
                </div>
                <!-- /.card -->
            </div>
        </div>
    </div>
    <!-- ./row -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->startPush('after-script'); ?>


<div class="modal fade" id="mymodal">
    <div class="modal-dialog">
        <form method="post" action="/products/import_excel" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Import Excel</h5>
                </div>
                <div class="modal-body">
                    <label>Pilih file excel</label>
                    <div class="form-group">
                        <input type="file" name="file" required="required">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Import</button>
                </div>
            </div>
        </form>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\serverc\xampp\htdocs\shayna-backend\resources\views/pages/products/index.blade.php ENDPATH**/ ?>