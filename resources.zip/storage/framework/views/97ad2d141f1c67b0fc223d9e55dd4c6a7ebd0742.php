<!-- jQuery -->

<!-- Jika modal ditdak tampil maka ganti jQuery dengan jQuery 3.5.1-->

<<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="/assets/backend/adminlte30/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="/assets/backend/adminlte30/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="/assets/backend/adminlte30/dist/js/adminlte.min.js"></script><?php /**PATH D:\serverc\xampp\htdocs\sialulus\resources\views/includes/script.blade.php ENDPATH**/ ?>