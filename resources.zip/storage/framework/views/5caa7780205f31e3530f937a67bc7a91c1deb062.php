<div class="card">
    <div class="card-header with-border">
        <h3 class="card-title"><?php echo e($title); ?></h3>
    </div>
    <div class="card-body">
        <?php echo e($slot); ?>

    </div>
    <?php echo e($footer); ?>

</div><?php /**PATH D:\serverc\xampp\htdocs\shayna-backend\resources\views/components/card.blade.php ENDPATH**/ ?>