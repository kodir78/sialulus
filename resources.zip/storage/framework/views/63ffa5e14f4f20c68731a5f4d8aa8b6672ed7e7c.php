<?php $__env->startSection('title'); ?>
    Manajemen Role
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>
                        Daftar 
                        <small>Role</small>
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('role.index')); ?>">Post</a></li>
                        <li class="breadcrumb-item active">Daftar Role</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4">
                    <?php $__env->startComponent('components.card'); ?>
                        <?php $__env->slot('title'); ?>
                        Tambah
                        <?php $__env->endSlot(); ?>
                        
                        <?php if(session('error')): ?>
                            <?php $__env->startComponent('components.alert', ['type' => 'danger']); ?>
                                <?php echo session('error'); ?>

                            <?php echo $__env->renderComponent(); ?>
                        <?php endif; ?>

                        <form role="form" action="<?php echo e(route('role.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="name">Role</label>
                                <input type="text" 
                                name="name"
                                class="form-control <?php echo e($errors->has('name') ? 'is-invalid':''); ?>" id="name" required>
                            </div>
                        <?php $__env->slot('footer'); ?>
                            <div class="card-footer">
                                <button class="btn btn-primary">Simpan</button>
                            </div>
                        </form>
                        <?php $__env->endSlot(); ?>
                    <?php echo $__env->renderComponent(); ?>
                </div>
                <div class="col-md-8">
                    <?php $__env->startComponent('components.card'); ?>
                        <?php $__env->slot('title'); ?>
                        List Role
                        <?php $__env->endSlot(); ?>
                        
                        <?php if(session('success')): ?>
                            <?php $__env->startComponent('components.alert', ['type' => 'success']); ?>
                                <?php echo session('success'); ?>

                            <?php echo $__env->renderComponent(); ?>
                        <?php endif; ?>
                        
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <td>#</td>
                                        <td>Role</td>
                                        <td>Guard</td>
                                        <td>Created At</td>
                                        <td>Aksi</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1; ?>
                                    <?php $__empty_1 = true; $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($row->name); ?></td>
                                        <td><?php echo e($row->guard_name); ?></td>
                                        <td><?php echo e($row->created_at); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('role.destroy', $row->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="_method" value="DELETE">
                                                <button class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center">Tidak ada data</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="float-right">
                            <?php echo $role->links(); ?>

                        </div>
                        <?php $__env->slot('footer'); ?>

                        <?php $__env->endSlot(); ?>
                    <?php echo $__env->renderComponent(); ?>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- /.content-wrapper -->
<?php $__env->startPush('after-script'); ?>


<div class="modal fade" id="mymodal">
    <div class="modal-dialog">
        <form method="post" action="/products/import_excel" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Import Excel</h5>
                </div>
                <div class="modal-body">
                    <label>Pilih file excel</label>
                    <div class="form-group">
                        <input type="file" name="file" required="required">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Import</button>
                </div>
            </div>
        </form>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\serverc\xampp\htdocs\shayna-backend\resources\views/pages/role/index.blade.php ENDPATH**/ ?>